package org.wit.android.helpers;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;

public class ContactHelper
{ 
  public static String getContact(Context context, Intent data)
  {
    String contact = "unable to find contact";
    Uri contactUri = data.getData();
    String[] queryFields = new String[] { ContactsContract.Contacts.DISPLAY_NAME };
    Cursor c = context.getContentResolver().query(contactUri, queryFields, null, null, null);
    if (c.getCount() == 0)
    {
      c.close();
      return contact;
    }
    c.moveToFirst();
    contact = c.getString(0);
    c.close();

    return contact;
  }
}