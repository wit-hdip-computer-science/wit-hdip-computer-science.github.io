package org.wit.myrent.activities;

import java.util.ArrayList;

import org.wit.android.helpers.IntentHelper;
import org.wit.myrent.R;
import org.wit.myrent.app.MyRentApp;
import org.wit.myrent.models.Portfolio;
import org.wit.myrent.models.Residence;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.app.ListFragment;
import android.support.v4.content.LocalBroadcastManager;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView.MultiChoiceModeListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;

public class ResidenceListFragment extends ListFragment implements  OnItemClickListener, 
																    MultiChoiceModeListener																   
{
  public static final String BROADCAST_ACTION = "org.wit.myrent.activities.BROADCAST";
  //public static final String EXTENDED_DATA_STATUS = "org.wit.myrent.activities.STATUS";
  
  private ArrayList<Residence> residences;
  private Portfolio portfolio;
  private ResidenceAdapter adapter;
  private ListView listView;

  private IntentFilter intentFilter;
  
  @Override
  public void onCreate(Bundle savedInstanceState)
  {
    super.onCreate(savedInstanceState);
    setHasOptionsMenu(true);
    getActivity().setTitle(R.string.app_name);

    MyRentApp app = (MyRentApp) getActivity().getApplication();
    portfolio = app.portfolio;
    residences = portfolio.getResidences();

    adapter = new ResidenceAdapter(getActivity(), residences);
    setListAdapter(adapter);
    
    // The filter's action is BROADCAST_ACTION
    intentFilter = new IntentFilter(BROADCAST_ACTION);
    registerBroadcastReceiver(intentFilter);
    
  }

  @Override
  public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState)
  {
    View v = super.onCreateView(inflater, parent, savedInstanceState);
    listView = (ListView) v.findViewById(android.R.id.list);
    listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);
    listView.setMultiChoiceModeListener(this);
    return v;
  }

  @Override
  public void onListItemClick(ListView l, View v, int position, long id)
  {
    Residence res = ((ResidenceAdapter) getListAdapter()).getItem(position);
    Intent i = new Intent(getActivity(), ResidenceActivity.class);
    i.putExtra(ResidenceFragment.EXTRA_RESIDENCE_ID, res.uuid);
    i.putExtra(ResidenceFragment.EXTRA_NEW_RESIDENCE, false);
    startActivityForResult(i, 0);
  }

  @Override
  public void onResume()
  {
    super.onResume();
    //((ResidenceAdapter) getListAdapter()).notifyDataSetChanged();
    notifyResidenceListChange();
  }

  private void notifyResidenceListChange()
  {
    ((ResidenceAdapter) getListAdapter()).notifyDataSetChanged();
  }
  
  @Override
  public void onCreateOptionsMenu(Menu menu, MenuInflater inflater)
  {
    super.onCreateOptionsMenu(menu, inflater);
    inflater.inflate(R.menu.residencelist, menu);
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item)
  {
    switch (item.getItemId())
    {
    case R.id.menu_item_new_residence:
      Residence residence = new Residence();
      portfolio.addResidence(residence);

      Intent i = new Intent(getActivity(), ResidenceActivity.class);
      i.putExtra(ResidenceFragment.EXTRA_RESIDENCE_ID, residence.uuid);
      i.putExtra(ResidenceFragment.EXTRA_NEW_RESIDENCE, true);
      startActivityForResult(i, 0);
      return true;
    default:
      return super.onOptionsItemSelected(item);
    }
  }

  @Override
  public void onItemClick(AdapterView<?> parent, View view, int position, long id)
  {
    Residence residence = adapter.getItem(position);
    IntentHelper.startActivityWithData(getActivity(), ResidenceActivity.class, "RESIDENCE_ID", residence.uuid);
  }

  /* ************ MultiChoiceModeListener methods (begin) *********** */
  @Override
  public boolean onCreateActionMode(ActionMode mode, Menu menu)
  {
    MenuInflater inflater = mode.getMenuInflater();
    inflater.inflate(R.menu.residence_list_context, menu);
    return true;
  }

  @Override
  public boolean onPrepareActionMode(ActionMode mode, Menu menu)
  {
    return false;
  }

  @Override
  public boolean onActionItemClicked(ActionMode mode, MenuItem item)
  {
    switch (item.getItemId())
    {
    case R.id.menu_item_delete_residence:
      deleteResidence(mode);
      return true;
    default:
      return false;
    }

  }

  private void deleteResidence(ActionMode mode)
  {
    for (int i = adapter.getCount() - 1; i >= 0; i--)
    {
      if (listView.isItemChecked(i))
      {
        portfolio.deleteResidence(getActivity(), adapter.getItem(i));      
      }
    }
    mode.finish();
    adapter.notifyDataSetChanged();
  }

  @Override
  public void onDestroyActionMode(ActionMode mode)
  {
  }

  @Override
  public void onItemCheckedStateChanged(ActionMode mode, int position, long id, boolean checked)
  {
  }
  private void registerBroadcastReceiver(IntentFilter intentFilter)
  {
 // Instantiates a new ResponseReceiver
    ResponseReceiver mResponseReceiver = new ResponseReceiver();
    // Registers the ResponseReceiver and its intent filters
    LocalBroadcastManager.getInstance(getActivity()).registerReceiver(mResponseReceiver, intentFilter);

  }
  /* ************ MultiChoiceModeListener methods (end) *********** */
  class ResidenceAdapter extends ArrayAdapter<Residence>
  {
    private Context context;

    public ResidenceAdapter(Context context, ArrayList<Residence> residences)
    {
      super(context, 0, residences);
      this.context = context;
    }

    @SuppressLint("InflateParams")
    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
      LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
      if (convertView == null)
      {
        convertView = inflater.inflate(R.layout.list_item_residence, null);
      }
      Residence res = getItem(position);

      TextView geolocation = (TextView) convertView.findViewById(R.id.residence_list_item_geolocation);
      geolocation.setText(res.geolocation);

      TextView dateTextView = (TextView) convertView.findViewById(R.id.residence_list_item_dateTextView);
      dateTextView.setText(res.getDateString());

      CheckBox rentedCheckBox = (CheckBox) convertView.findViewById(R.id.residence_list_item_isrented);
      rentedCheckBox.setChecked(res.rented);

      return convertView;
    }
  }
  
  /* *************************************************************************** */
  //Broadcast receiver for receiving status updates from the IntentService
  private class ResponseReceiver extends BroadcastReceiver
  {
     // Prevents instantiation
     private void ResponseReceiver() {
     }
     // Called when the BroadcastReceiver gets an Intent it's registered to receive
    @Override
    public void onReceive(Context context, Intent intent)
    {
      notifyResidenceListChange();      
    }
  }
}