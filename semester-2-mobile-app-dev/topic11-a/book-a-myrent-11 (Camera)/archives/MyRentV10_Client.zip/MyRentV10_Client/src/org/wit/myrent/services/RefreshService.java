package org.wit.myrent.services;

import java.util.List;

import org.wit.android.helpers.LogHelpers;
import org.wit.myrent.activities.ResidenceListFragment;
import org.wit.myrent.app.MyRentApp;
import org.wit.myrent.http.Rest;
import org.wit.myrent.models.JsonParsers;
import org.wit.myrent.models.Portfolio;
import org.wit.myrent.models.Residence;

import android.app.IntentService;
import android.content.Intent;
import android.support.v4.content.LocalBroadcastManager;
import android.widget.Toast;

public class RefreshService extends IntentService
{
  private static final String TAG = RefreshService.class.getSimpleName();
  public RefreshService()
  {
    super(TAG);
  }
  
  @Override
  public void onCreate()
  {
    super.onCreate();
    LogHelpers.info(this, "onCreated");
  }
  
  /*
   * invoked on worker thread(non-Javadoc)
   * @see android.app.IntentService#onHandleIntent(android.content.Intent)
   */
  @Override
  protected void onHandleIntent(Intent intent)
  {
    MyRentApp app = (MyRentApp)getApplication();
    Portfolio portfolio = app.portfolio;
    try
    {
      String response =  Rest.get("/api/residences");
      List<Residence> residences = JsonParsers.json2Residences(response);
      portfolio.updateResidences(residences);
      Toast.makeText(this, "Retrieved residence list", Toast.LENGTH_SHORT).show();
      LogHelpers.info(this, "Retrieved residence list");
      broadcastIntent();
    }
    catch(Exception e)
    {
      LogHelpers.info(this, "failed to retrieve residences");
      Toast.makeText(this, "failed to retrieve residences", Toast.LENGTH_SHORT).show();
    }    
  }
  
  private void broadcastIntent()
  {
    /*
     * Creates a new Intent containing a Uri object
     * BROADCAST_ACTION is a custom Intent action
     */
    Intent localIntent = new Intent(ResidenceListFragment.BROADCAST_ACTION);
            // Puts the status into the Intent
            //.putExtra(Constants.EXTENDED_DATA_STATUS, status);
    // Broadcasts the Intent to receivers in this app.
    LocalBroadcastManager.getInstance(this).sendBroadcast(localIntent);
  }
  @Override
  public void onDestroy()
  {
    super.onDestroy();
    LogHelpers.info(this, "onDestroyed");
  }
}
