package org.wit.myrent.services;

import org.wit.android.helpers.LogHelpers;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class BootReceiver extends BroadcastReceiver
{

  private static final long DEFAULT_INTERVAL = AlarmManager.INTERVAL_FIFTEEN_MINUTES;

  @Override
  public void onReceive(Context context, Intent intent)
  {

    SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
    long interval = Long.parseLong(prefs.getString("refresh_interval", Long.toString(DEFAULT_INTERVAL)));
    interval *= 1000;//minutes to milliseconds since input at settings menu is specified in minutes
    PendingIntent operation = PendingIntent.getService(context, -1, new Intent(context, RefreshService.class),
        PendingIntent.FLAG_UPDATE_CURRENT);

    AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

    if (interval == 0)
    {
      alarmManager.cancel(operation);
      LogHelpers.info(this, "cancelling operation");
    }
    else
    {
      alarmManager.setInexactRepeating(AlarmManager.RTC, System.currentTimeMillis(), interval, operation);
      LogHelpers.info(this, "setting repeat operation for: " + interval);
    }
    LogHelpers.info(this, "onReceived");
    
  }
}
