package org.wit.myrent.models;

import java.lang.reflect.Type;
import java.util.List;


import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class JsonParsers
{
  static Gson gson = new Gson();
  
  public static Residence json2Residence(String json)
  {
    return gson.fromJson(json, Residence.class);   
  }
  
  public static List<Residence> json2Residences(String json)
  {
    Type collectionType = new TypeToken<List<Residence>>() {}.getType();
    return gson.fromJson(json, collectionType); 
  }
  
  public static String residence2Json(Object obj)
  {
    return gson.toJson(obj);
  }   
}