package org.wit.myrent.models;

import static org.wit.android.helpers.LogHelpers.info;

import java.util.ArrayList;
import java.util.List;

import org.wit.android.helpers.IntentHelper;
import org.wit.myrent.http.Response;

import android.content.Context;
import android.util.Log;

public class Portfolio implements Response<Residence>
{
  private ArrayList<Residence> residences;

  public Portfolio()
  {
    residences = new ArrayList<Residence>(); 
  }

  public ArrayList<Residence> getResidences()
  {
    return this.residences;
  }
  
  public void setResidences(ArrayList<Residence> residences)
  {
    this.residences = residences;
  }

  public void addResidence(Residence residence)
  {
    residences.add(residence);
  }

  public void deleteResidence(Residence c)
  {
    residences.remove(c);
  }
  public Residence getResidence(String id)
  {
    Log.i(this.getClass().getSimpleName(), "UUID parameter id: "+ id);
    
    for (Residence res : residences)
    {
      if(id.equals(res.uuid))
      {
        return res; 
      }
    }
    info(this, "Failed to find residence matching id " + id);
    return null;
  } 
  
  public void updateResidences(List<Residence> rxd)
  {
    residences.clear();
    residences.addAll(rxd);
    //TODO invoke notifyDataSetChanged() in ResidenceListFragment
  }
  /*============================Response<Residence>================================*/  
  public void createResidence(Context context, Residence residence)
  {
    ResidenceServiceAPI.createResidence(context, this, "Saving residence", residence);
  }
  
  /*
   * To update an existing Residence instance:
   *    Delete existing
   *    Replace with modified
   */
  public void updateResidence(Context context, Residence residence)
  {
    deleteResidence(context,residence);
    ResidenceServiceAPI.createResidence(context, this, "Updating residence", residence);
    residences.add(residence);
  }
  
  public void deleteResidence(Context context, Residence residence)
  {
    ResidenceServiceAPI.deleteResidence(context, this, "Deleting residence", residence);
    this.deleteResidence(residence);
  }
  
  @Override
  public void setReponse(List<Residence> aList)
  {    
  }
  
  @Override
  public void setReponse(Residence residence)
  {
  }

  @Override
  public void errorOccurred(Exception e)
  {
    info(this, e.getLocalizedMessage());
  }
}