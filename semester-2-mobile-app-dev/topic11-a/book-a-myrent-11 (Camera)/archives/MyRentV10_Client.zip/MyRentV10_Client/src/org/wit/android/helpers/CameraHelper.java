package org.wit.android.helpers;

import java.util.List;


import org.wit.myrent.models.Residence;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.hardware.Camera.Size;
import android.view.Display;
import android.widget.ImageView;

public class CameraHelper
{
  /**
   * a simple algorithm to get the largest size available. For a more robust
   * version, see CameraPreview.java in the ApiDemos sample app from Android.
   */
  public static Size getBestSupportedSize(List<Size> sizes, int width, int height)
  {
    Size bestSize = sizes.get(0);
    int largestArea = bestSize.width * bestSize.height;
    for (Size s : sizes)
    {
      int area = s.width * s.height;
      if (area > largestArea)
      {
        bestSize = s;
        largestArea = area;
      }
    }
    return bestSize;
  }
  
  public static void showPhoto(Activity activity, Residence res, ImageView photoView)
  {
    // (re)set the image button's image based on our photo
    //Photo p = res.photo;
    String filename = res.photoFileName;
    BitmapDrawable b = null;
    if (filename != null)
    {
      //String path = activity.getFileStreamPath(p.getFilename()).getAbsolutePath();
      String path = activity.getFileStreamPath(filename).getAbsolutePath();
      b = getScaledDrawable(activity, path);
    }
    if (b != null)
    {
      photoView.setImageDrawable(b);
    }
  }
  
  /**
   * Get a BitmapDrawable from a local file that is scaled down to fit the
   * current Window size.
   */
  @SuppressWarnings("deprecation")
  public static BitmapDrawable getScaledDrawable(Activity a, String path)
  {
    Display display = a.getWindowManager().getDefaultDisplay();
    float destWidth = display.getWidth();
    float destHeight = display.getHeight();

    // read in the dimensions of the image on disk
    BitmapFactory.Options options = new BitmapFactory.Options();
    options.inJustDecodeBounds = true;
    BitmapFactory.decodeFile(path, options);

    float srcWidth = options.outWidth;
    float srcHeight = options.outHeight;

    int inSampleSize = 1;
    if (srcHeight > destHeight || srcWidth > destWidth)
    {
      if (srcWidth > srcHeight)
      {
        inSampleSize = Math.round((float) srcHeight / (float) destHeight);
      }
      else
      {
        inSampleSize = Math.round((float) srcWidth / (float) destWidth);
      }
    }

    options = new BitmapFactory.Options();
    options.inSampleSize = inSampleSize;

    Bitmap bitmap = BitmapFactory.decodeFile(path, options);
    return new BitmapDrawable(a.getResources(), bitmap);
  }

  public static void cleanImageView(ImageView imageView)
  {
    if (!(imageView.getDrawable() instanceof BitmapDrawable))
      return;

    // clean up the view's image for the sake of memory
    BitmapDrawable b = (BitmapDrawable) imageView.getDrawable();
    b.getBitmap().recycle();
    imageView.setImageDrawable(null);
  }
}
