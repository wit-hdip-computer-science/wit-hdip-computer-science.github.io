package org.wit.myrent.models;

import java.util.List;

import android.content.Context;
import org.wit.myrent.http.Request;
import org.wit.myrent.http.Response;
import org.wit.myrent.http.Rest;

public class ResidenceServiceAPI
{ 
  public static void getResidences(Context context, Response<Residence> response, String dialogMesssage)
  {
    new GetResidences(context, response, dialogMesssage).execute();
  }
  
  public static void createResidence(Context context, Response<Residence> response, String dialogMesssage, Residence residence)
  {
    new CreateResidence(context, response, dialogMesssage).execute(residence);
  }
  
  public static void deleteResidence(Context context, Response<Residence> response, String dialogMesssage, Residence residence)
  {
    new DeleteResidence(context, response, dialogMesssage).execute(residence);
  }
}
/*================================================================================*/
class GetResidences extends Request
{
  public GetResidences(Context context, Response<Residence> callback, String message)
  {
    super(context, callback, message);
  }

  @Override
  protected List<Residence> doRequest(Object... params) throws Exception
  {
    String response =  Rest.get("/api/residences");
    List<Residence> residenceList = JsonParsers.json2Residences(response);
    return residenceList;
  }
}
 
class CreateResidence extends Request
{
  public CreateResidence(Context context, Response<Residence> callback, String message)
  {
    super(context, callback, message);
  }

  @Override
  protected Residence doRequest(Object... params) throws Exception
  {
    String response = Rest.post ("/api/residences", JsonParsers.residence2Json(params[0]));
    return JsonParsers.json2Residence(response);
  }
}

class DeleteResidence extends Request 
{
  public DeleteResidence(Context context, Response<Residence> callback, String message)
  {
    super(context, callback, message);
  }
  
  @Override 
  protected Residence doRequest(Object... params) throws Exception
  {
    String uuid = ((Residence)params[0]).uuid;
    String path = "/api/residences/" + uuid; 
    String response = Rest.delete (path);
    return JsonParsers.json2Residence(response); 
  }
}
