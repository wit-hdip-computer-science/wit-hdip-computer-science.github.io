package org.wit.myrent.models;


import java.util.Date;
import java.util.UUID;

import org.wit.myrent.R;

import android.content.Context;

public class Residence
{
  public String     uuid         ;
  public String     geolocation  ;
  public String     date         ;
  public boolean    rented       ;
  public String     tenant       ;
  public double     zoom         ;//zoom level of accompanying map
  public String     photoFileName;      

  public Residence()
  {
    uuid          = UUID.randomUUID().toString();
    geolocation   = "52.253456,-7.187162";
    date          = new Date().toString();
    rented        = true;
    tenant        = "A. N. Other";
    zoom          = 16.0f;
    photoFileName = "";
    
  }
  
  public String getDateString()
  {
    //return "Registered: " + DateFormat.getDateTimeInstance().format(date);
    return "Registered: " + date;
  }
  
  public String getResidenceReport(Context context)
  {
    String rentedString = null;
    if (rented)
    {
      rentedString = context.getString(R.string.residence_report_rented);
    }
    else
    {
      rentedString = context.getString(R.string.residence_report_not_rented);
    }
    //String dateFormat = "EEE, MMM dd";
    //String dateString = android.text.format.DateFormat.format(dateFormat, date).toString();
    String prospectiveTenant = tenant;
    if (tenant == null)
    {
      prospectiveTenant = context.getString(R.string.residence_report_nobody_interested);
    }
    else
    {
      prospectiveTenant = context.getString(R.string.residence_report_prospective_tenant, tenant);
    }
    //String report =  "Location " + geolocation + " Date: " + dateString + " " + rentedString + " " + prospectiveTenant;
    String report =  "Location " + geolocation + " Date: " + date + " " + rentedString + " " + prospectiveTenant;
    return report;
  }
}