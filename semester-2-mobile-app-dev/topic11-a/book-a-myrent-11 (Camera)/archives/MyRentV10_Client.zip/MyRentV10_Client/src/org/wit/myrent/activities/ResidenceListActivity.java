package org.wit.myrent.activities;

import java.util.ArrayList;
import java.util.List;

import org.wit.android.helpers.LogHelpers;
import org.wit.myrent.R;
import org.wit.myrent.app.MyRentApp;
import org.wit.myrent.http.Response;
import org.wit.myrent.models.Residence;
import org.wit.myrent.services.RefreshService;
import org.wit.myrent.settings.SettingsActivity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.view.Menu;
import android.view.MenuItem;


public class ResidenceListActivity extends FragmentActivity //implements Response<Residence>
{
  MyRentApp app;

  public void onCreate(Bundle savedInstanceState)
  {
    app = (MyRentApp) getApplication();
    super.onCreate(savedInstanceState);
    setContentView(R.layout.fragment_container);
    createFragment();
    /* Retrieve list of residences from server on first instantiation only this class
     * Having obtained list then complete the creation of fragment
     * Use flag in MyRentApp (residencesRetrieved) to check if residences already retrieved
     */
/*    if (app.residencesRetrieved == false)
    {
      ResidenceServiceAPI.getResidences(this, this, "Retrieving residences");
    }
    else
    {
      createFragment();
    }*/
  }
  
  private void createFragment()
  {
    FragmentManager manager = getSupportFragmentManager();
    Fragment fragment = manager.findFragmentById(R.id.fragmentContainer);
    if (fragment == null)
    {
      fragment = new ResidenceListFragment();
      manager.beginTransaction().add(R.id.fragmentContainer, fragment).commit();
    }
  }
  
  @Override
  public boolean onCreateOptionsMenu(Menu menu)
  {
    getMenuInflater().inflate(R.menu.main, menu);
    return super.onCreateOptionsMenu(menu);
  }
  
  @Override
  public boolean onOptionsItemSelected(MenuItem item)
  {
    int id =item.getItemId();
    switch(id)
    {
    case R.id.action_refresh:
      startService(new Intent(this, RefreshService.class));
      return true;
      
    case R.id.action_settings:
      startActivity(new Intent(this, SettingsActivity.class));
      return true;
    
    default:
      return super.onOptionsItemSelected(item);
    }
    
  }
 /*===================== Response<Residence> method implementations====================*/
/* @Override
 public void setReponse(List<Residence> aList) 
 {
   app.portfolio.setResidences((ArrayList<Residence>) aList);
   createFragment();
   app.residencesRetrieved = true;
 }

 @Override 
 public void errorOccurred(Exception e) 
 {
    LogHelpers.info(this, e.getMessage());   
 }
 @Override
 public void setReponse(Residence anObject) {}*/

}